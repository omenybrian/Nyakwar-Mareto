OMENY BRIAN OKO — WEBSITE PUBLISHING NOTES

Files:
- index.html  Main responsive website and SEO metadata
- robots.txt  Crawler instructions
- sitemap.xml Sitemap for Google and other search engines

BEFORE PUBLISHING
1. Replace https://omenybrianoko.com/ in index.html, robots.txt and sitemap.xml with your actual domain if different.
2. Replace YOUR-EMAIL@example.com with your real professional email.
3. Replace the LinkedIn placeholder with your real LinkedIn profile.
4. Review every biographical statement for accuracy.

PUBLISHING
Upload all three website files to the public root of your hosting account. The homepage should be reachable at https://your-domain.com/.

GOOGLE SEARCH
After the site is live:
1. Open Google Search Console.
2. Add and verify your domain.
3. Submit https://your-domain.com/sitemap.xml.
4. Use URL Inspection for https://your-domain.com/ and request indexing.
5. Keep your exact name “Omeny Brian Ooko” consistent across legitimate professional profiles and link those profiles to the site where appropriate.

IMPORTANT
A sitemap and SEO metadata do not guarantee immediate Google indexing or ranking. Keep the website accessible, accurate, secure (HTTPS), and updated.
